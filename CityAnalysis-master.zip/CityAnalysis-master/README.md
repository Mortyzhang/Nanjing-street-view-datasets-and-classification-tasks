# CityAnalysis
This a project for city building sence classification

# Useage

install PyTorch 1.5+ and torchvision 0.6+:
```
conda install -c pytorch pytorch torchvision
```

install prefetch_generator
```
pip install prefetch_generator
```

install imgaug
```
pip install git+https://github.com/aleju/imgaug
```

# Pre-Model
using efficientnet_b2 with multi-label 
https://drive.google.com/drive/folders/1Q-cbezLxOx8DcsPG1EnEXiAdYeMDxoHy?usp=sharing

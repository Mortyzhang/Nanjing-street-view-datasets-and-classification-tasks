import cv2
import numpy as np

image = cv2.imread('city_inference/1.png')
print(image)
print(np.shape(image))